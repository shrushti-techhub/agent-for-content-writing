
import React from 'react';
import { SavedScript } from '../types';

interface SavedScriptsProps {
  scripts: SavedScript[];
  onDelete: (id: string) => void;
  onPreview: (script: SavedScript) => void;
}

const SavedScripts: React.FC<SavedScriptsProps> = ({ scripts, onDelete, onPreview }) => {
  if (scripts.length === 0) {
    return (
      <div className="py-20 text-center bg-white rounded-[40px] border-2 border-dashed border-slate-100">
        <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <svg className="w-8 h-8 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
        </div>
        <h3 className="text-lg font-bold text-slate-800">No saved scripts yet</h3>
        <p className="text-sm text-slate-400 mt-1">Scripts you save will appear here for easy access.</p>
      </div>
    );
  }

  return (
    <section id="library" className="py-20 border-t border-slate-100">
      <div className="flex items-center justify-between mb-10">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">My Script Library</h2>
          <p className="text-slate-500 mt-1">Your collection of high-performing content scripts.</p>
        </div>
        <span className="bg-indigo-50 text-indigo-700 px-4 py-1 rounded-full text-xs font-bold uppercase tracking-widest">
          {scripts.length} Total
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {scripts.map((script) => (
          <div key={script.id} className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-sm hover:shadow-xl transition-all group flex flex-col h-full">
            <div className="flex justify-between items-start mb-4">
              <span className="bg-slate-100 text-slate-500 text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded">
                {script.request.platform}
              </span>
              <button 
                onClick={() => onDelete(script.id)}
                className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-full transition-all"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
              </button>
            </div>
            
            <h3 className="text-lg font-bold text-slate-800 mb-2 line-clamp-1">{script.title}</h3>
            <p className="text-xs text-slate-400 mb-6 line-clamp-3 leading-relaxed">
              "{script.hook}"
            </p>

            <div className="mt-auto pt-6 flex items-center justify-between border-t border-slate-50">
              <span className="text-[10px] text-slate-300 font-medium">
                {new Date(script.timestamp).toLocaleDateString()}
              </span>
              <button 
                onClick={() => onPreview(script)}
                className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 transition-colors"
              >
                Open Script
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" /></svg>
              </button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default SavedScripts;
