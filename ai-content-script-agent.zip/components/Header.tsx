
import React from 'react';
import { User } from '../types';

interface HeaderProps {
  user: User | null;
  onSignInClick: () => void;
  onSignOut: () => void;
}

const Header: React.FC<HeaderProps> = ({ user, onSignInClick, onSignOut }) => {
  const scrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-50 glass border-b border-slate-200 py-4 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-200">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
            </svg>
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 tracking-tight leading-none">Script Agent</h1>
            <p className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest mt-1">AI Powered Content Mastery</p>
          </div>
        </div>
        
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-500">
          <button onClick={() => scrollTo('how-it-works')} className="hover:text-indigo-600 transition-colors">How it works</button>
          <button onClick={() => scrollTo('templates')} className="hover:text-indigo-600 transition-colors">Templates</button>
          {user && (
            <button onClick={() => scrollTo('library')} className="hover:text-indigo-600 transition-colors">My Library</button>
          )}
          
          <div className="w-px h-6 bg-slate-200 mx-2"></div>
          
          {user ? (
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-3 pr-2">
                <div className="text-right">
                  <p className="text-xs font-bold text-slate-800 leading-none">{user.name}</p>
                  <button onClick={onSignOut} className="text-[10px] text-slate-400 hover:text-red-500 transition-colors">Sign Out</button>
                </div>
                <img src={user.avatar} alt={user.name} className="w-8 h-8 rounded-full bg-slate-100 border border-slate-200 shadow-sm" />
              </div>
            </div>
          ) : (
            <button 
              onClick={onSignInClick}
              className="bg-slate-900 text-white px-5 py-2 rounded-xl hover:bg-slate-800 transition-all shadow-md text-xs font-bold tracking-wide"
            >
              Sign In
            </button>
          )}
        </nav>
      </div>
    </header>
  );
};

export default Header;
