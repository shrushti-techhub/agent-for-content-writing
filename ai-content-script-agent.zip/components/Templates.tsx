
import React from 'react';
import { ScriptRequest, Tone } from '../types';

interface TemplatesProps {
  onSelect: (template: ScriptRequest) => void;
}

const Templates: React.FC<TemplatesProps> = ({ onSelect }) => {
  const templates = [
    {
      name: "Student Skill Reel",
      request: {
        topic: "How college students can learn valuable digital skills from home for free",
        platform: "Instagram Reel",
        audience: "College Students",
        tone: Tone.MOTIVATIONAL,
        duration: "45 seconds"
      },
      tag: "Social",
      color: "bg-pink-100 text-pink-700"
    },
    {
      name: "AI Business Pitch",
      request: {
        topic: "Introducing a new AI-powered workflow automation tool for small agencies",
        platform: "LinkedIn Post/Video",
        audience: "Agency Owners",
        tone: Tone.PROFESSIONAL,
        duration: "60 seconds"
      },
      tag: "Business",
      color: "bg-blue-100 text-blue-700"
    },
    {
      name: "Productivity Hacks",
      request: {
        topic: "3 unconventional productivity hacks to reclaim 2 hours of your day",
        platform: "YouTube Short",
        audience: "Busy Professionals",
        tone: Tone.EDUCATIONAL,
        duration: "30 seconds"
      },
      tag: "Education",
      color: "bg-emerald-100 text-emerald-700"
    },
    {
      name: "Conference Opening",
      request: {
        topic: "Welcome speech for a tech conference about the future of human-AI collaboration",
        platform: "Professional Presentation",
        audience: "Tech Enthusiasts & Developers",
        tone: Tone.MOTIVATIONAL,
        duration: "3 minutes"
      },
      tag: "Event",
      color: "bg-amber-100 text-amber-700"
    }
  ];

  return (
    <section id="templates" className="py-20 border-t border-slate-100">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Start with a Template</h2>
          <p className="text-slate-500 mt-2">Pick a starting point to see how the agent handles different formats.</p>
        </div>
        <div className="flex gap-2">
          <div className="h-10 px-4 rounded-full bg-slate-100 flex items-center text-xs font-bold text-slate-500">Fast Start</div>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {templates.map((t, idx) => (
          <button
            key={idx}
            onClick={() => {
              onSelect(t.request);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="text-left bg-white p-6 rounded-3xl border border-slate-100 shadow-sm hover:border-indigo-300 hover:shadow-indigo-50/50 transition-all group"
          >
            <span className={`text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded ${t.color}`}>
              {t.tag}
            </span>
            <h3 className="text-lg font-bold text-slate-800 mt-4 mb-2 group-hover:text-indigo-600 transition-colors">{t.name}</h3>
            <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
              {t.request.topic}
            </p>
            <div className="mt-6 flex items-center justify-between">
              <span className="text-[10px] font-bold text-slate-500 uppercase">{t.request.platform}</span>
              <svg className="w-4 h-4 text-indigo-500 transform translate-x-0 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </div>
          </button>
        ))}
      </div>
    </section>
  );
};

export default Templates;
