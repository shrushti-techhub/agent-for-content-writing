
import React, { useState, useEffect } from 'react';
import { ScriptRequest, Tone } from '../types';

interface ScriptFormProps {
  onSubmit: (data: ScriptRequest) => void;
  isLoading: boolean;
  prefill?: ScriptRequest | null;
}

const ScriptForm: React.FC<ScriptFormProps> = ({ onSubmit, isLoading, prefill }) => {
  const [formData, setFormData] = useState<ScriptRequest>({
    topic: '',
    platform: 'Instagram Reel',
    audience: 'General Audience',
    tone: Tone.CASUAL,
    duration: '60 seconds'
  });

  useEffect(() => {
    if (prefill) {
      setFormData(prefill);
    }
  }, [prefill]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const platforms = [
    'Instagram Reel',
    'TikTok',
    'YouTube Short',
    'YouTube Longform',
    'LinkedIn Post/Video',
    'Professional Presentation',
    'Podcast Segment',
    'Email Newsletter'
  ];

  const durations = [
    '15 seconds',
    '30 seconds',
    '60 seconds',
    '90 seconds',
    '3 minutes',
    '5 minutes',
    '200 words',
    '500 words'
  ];

  return (
    <form onSubmit={handleSubmit} className="bg-white p-8 rounded-3xl shadow-xl shadow-slate-200/50 border border-slate-100">
      <h2 className="text-lg font-bold text-slate-800 mb-6 flex items-center gap-2">
        <span className="w-1.5 h-6 bg-indigo-500 rounded-full"></span>
        Configure Your Script
      </h2>

      <div className="space-y-5">
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">What's the topic?</label>
          <textarea
            required
            className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all bg-slate-50 min-h-[100px] text-slate-700"
            placeholder="e.g. 5 productivity tips for busy freelancers..."
            value={formData.topic}
            onChange={(e) => setFormData({ ...formData, topic: e.target.value })}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">Platform</label>
            <select
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-700 focus:ring-2 focus:ring-indigo-500"
              value={formData.platform}
              onChange={(e) => setFormData({ ...formData, platform: e.target.value })}
            >
              {platforms.map(p => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">Duration</label>
            <select
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-700 focus:ring-2 focus:ring-indigo-500"
              value={formData.duration}
              onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
            >
              {durations.map(d => <option key={d} value={d}>{d}</option>)}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">Target Audience</label>
          <input
            type="text"
            className="w-full px-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-700 focus:ring-2 focus:ring-indigo-500"
            placeholder="e.g. Corporate managers, Students..."
            value={formData.audience}
            onChange={(e) => setFormData({ ...formData, audience: e.target.value })}
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">Tone & Style</label>
          <div className="grid grid-cols-2 gap-2">
            {Object.values(Tone).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setFormData({ ...formData, tone: t })}
                className={`px-4 py-2 rounded-lg text-sm font-medium capitalize transition-all border ${
                  formData.tone === t
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-100'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        <button
          type="submit"
          disabled={isLoading || !formData.topic}
          className={`w-full py-4 mt-4 rounded-xl font-bold text-white transition-all transform hover:scale-[1.02] active:scale-[0.98] shadow-lg ${
            isLoading || !formData.topic
              ? 'bg-slate-400 cursor-not-allowed'
              : 'bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 shadow-indigo-200'
          }`}
        >
          {isLoading ? (
            <span className="flex items-center justify-center gap-2">
              <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Writing Script...
            </span>
          ) : 'Generate Content Script'}
        </button>
      </div>
    </form>
  );
};

export default ScriptForm;
