
import React, { useState, useEffect, useRef } from 'react';
import { ScriptOutput, ScriptRequest, User } from '../types';

interface ScriptDisplayProps {
  script: ScriptOutput;
  request: ScriptRequest;
  user: User | null;
  onSave: (title: string) => void;
  onSignInRequired: () => void;
  isSaved?: boolean;
}

const ScriptDisplay: React.FC<ScriptDisplayProps> = ({ script, request, user, onSave, onSignInRequired, isSaved }) => {
  const [view, setView] = useState<'standard' | 'teleprompter'>('standard');
  const [scrollSpeed, setScrollSpeed] = useState(2);
  const [isScrolling, setIsScrolling] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let interval: any;
    if (isScrolling && view === 'teleprompter') {
      interval = setInterval(() => {
        if (scrollRef.current) {
          scrollRef.current.scrollTop += scrollSpeed;
        }
      }, 50);
    }
    return () => clearInterval(interval);
  }, [isScrolling, scrollSpeed, view]);

  const copyToClipboard = () => {
    const full = `${script.hook}\n\n${script.coreMessage}\n\n${script.cta}`;
    navigator.clipboard.writeText(full);
    alert('Script copied to clipboard!');
  };

  const handleSave = () => {
    if (!user) {
      onSignInRequired();
      return;
    }
    const defaultTitle = request.topic.length > 30 ? request.topic.substring(0, 30) + "..." : request.topic;
    const title = prompt("Enter a title for this script:", defaultTitle);
    if (title) onSave(title);
  };

  const getPlatformBranding = () => {
    const p = request.platform.toLowerCase();
    if (p.includes('reel') || p.includes('instagram')) {
      return {
        gradient: "from-[#f9ce34] via-[#ee2a7b] to-[#6228d7]",
        accent: "text-[#ee2a7b]",
        label: "Instagram Style",
        logo: (
          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/>
          </svg>
        )
      };
    }
    if (p.includes('short') || p.includes('youtube')) {
      return {
        gradient: "from-[#ff0000] to-[#282828]",
        accent: "text-[#ff0000]",
        label: "YouTube Shorts Style",
        logo: (
          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
            <path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"/>
          </svg>
        )
      };
    }
    return {
      gradient: "from-indigo-600 to-violet-700",
      accent: "text-indigo-600",
      label: "Creative Agent Style",
      logo: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
      )
    };
  };

  const branding = getPlatformBranding();

  if (view === 'teleprompter') {
    return (
      <div className="fixed inset-0 z-[100] bg-black flex flex-col animate-in fade-in duration-300">
        <div className="p-4 bg-zinc-900 flex justify-between items-center text-white border-b border-zinc-800">
          <button 
            onClick={() => setView('standard')}
            className="flex items-center gap-2 text-sm font-medium hover:text-indigo-400 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
            Back to Editor
          </button>
          <div className="flex items-center gap-6">
             <div className="flex items-center gap-3">
               <span className="text-xs uppercase tracking-widest text-zinc-500 text-black">Speed</span>
               <input 
                type="range" min="1" max="10" 
                value={scrollSpeed} 
                onChange={(e) => setScrollSpeed(Number(e.target.value))}
                className="w-24 h-1 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
               />
             </div>
             <button 
              onClick={() => setIsScrolling(!isScrolling)}
              className={`px-6 py-2 rounded-full font-bold transition-all ${isScrolling ? 'bg-red-600' : 'bg-indigo-600'}`}
             >
              {isScrolling ? 'STOP' : 'START'}
             </button>
          </div>
        </div>
        <div 
          ref={scrollRef}
          className="flex-1 overflow-y-auto px-10 py-48 text-center"
        >
          <div className="max-w-4xl mx-auto space-y-24">
            <div className={`text-3xl font-bold uppercase tracking-[0.3em] mb-4 ${branding.accent}`}>HOOK</div>
            <p className="text-white text-5xl md:text-7xl font-bold leading-tight">{script.hook}</p>
            
            <div className="text-zinc-500 text-3xl font-bold uppercase tracking-[0.3em] mb-4">MESSAGE</div>
            <p className="text-white text-5xl md:text-7xl font-medium leading-tight whitespace-pre-wrap">{script.coreMessage}</p>
            
            <div className={`text-3xl font-bold uppercase tracking-[0.3em] mb-4 ${branding.accent}`}>CTA</div>
            <p className="text-white text-5xl md:text-7xl font-bold leading-tight">{script.cta}</p>
            
            <div className="h-96"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="bg-white rounded-[40px] shadow-2xl border border-slate-100 overflow-hidden relative">
        {/* Background Decorative Logo/Pattern */}
        <div className={`absolute top-0 right-0 w-64 h-64 bg-gradient-to-br ${branding.gradient} opacity-5 blur-[80px] -z-0`}></div>
        
        <div className={`bg-gradient-to-r ${branding.gradient} text-white px-8 py-6 flex justify-between items-center relative z-10`}>
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/20 rounded-lg backdrop-blur-md">
                {branding.logo}
            </div>
            <div>
                <h2 className="text-sm font-black tracking-widest uppercase opacity-90 leading-none">{branding.label}</h2>
                <p className="text-[10px] font-bold mt-1 opacity-70">OPTIMIZED CONTENT</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setView('teleprompter')}
              className="text-xs font-bold text-white hover:opacity-80 transition-opacity flex items-center gap-2 uppercase tracking-widest"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
              Studio
            </button>
            <div className="w-px h-4 bg-white/30"></div>
            <button 
              onClick={handleSave}
              disabled={isSaved}
              className={`text-xs font-bold transition-all uppercase tracking-widest flex items-center gap-2 ${isSaved ? 'opacity-50 cursor-default' : 'hover:scale-110 active:scale-95'}`}
            >
              {isSaved ? 'Saved' : 'Save'}
            </button>
            <div className="w-px h-4 bg-white/30"></div>
            <button 
              onClick={copyToClipboard}
              className="text-xs font-bold hover:opacity-80 transition-opacity uppercase tracking-widest"
            >
              Copy
            </button>
          </div>
        </div>

        <div className="p-10 space-y-12 relative z-10">
          <section className="relative group">
            <div className={`absolute -left-10 top-0 bottom-0 w-1.5 bg-gradient-to-b ${branding.gradient} rounded-full opacity-0 group-hover:opacity-100 transition-opacity`}></div>
            <h3 className={`text-[10px] font-black uppercase tracking-[0.4em] mb-4 ${branding.accent}`}>Phase 1: The Hook</h3>
            <div className="text-2xl font-black text-slate-800 leading-tight italic">
              "{script.hook}"
            </div>
          </section>

          <section>
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] mb-4">Phase 2: Core Value</h3>
            <div className="text-lg text-slate-700 leading-relaxed whitespace-pre-wrap font-medium">
              {script.coreMessage}
            </div>
          </section>

          <section className="bg-slate-50/80 backdrop-blur-sm p-10 rounded-[32px] border border-slate-100 shadow-inner group overflow-hidden relative">
            <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl ${branding.gradient} opacity-5 -mr-10 -mt-10 blur-2xl group-hover:opacity-20 transition-opacity`}></div>
            <h3 className={`text-[10px] font-black uppercase tracking-[0.4em] mb-4 ${branding.accent}`}>Phase 3: Action (CTA)</h3>
            <div className="text-xl font-black text-slate-900 leading-tight relative z-10">
              {script.cta}
            </div>
          </section>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {script.deliveryTips.map((tip, idx) => (
          <div key={idx} className="bg-white/80 backdrop-blur-md border border-slate-200 p-6 rounded-[24px] flex gap-5 items-start shadow-sm hover:shadow-md transition-shadow">
            <span className={`w-8 h-8 rounded-xl bg-gradient-to-br ${branding.gradient} text-white flex items-center justify-center text-[10px] font-black shrink-0 mt-0.5 shadow-lg`}>
                {idx + 1}
            </span>
            <p className="text-sm text-slate-600 font-medium leading-relaxed">{tip}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ScriptDisplay;
