
import { GoogleGenAI, Type } from "@google/genai";
import { ScriptRequest, ScriptOutput } from "../types";

export const generateScript = async (request: ScriptRequest): Promise<ScriptOutput> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  // Integrating the user's specific "Master Prompt" requirements
  const systemInstruction = `
You are AI Content Script Agent, a professional AI specialized in creating high-quality, engaging, and platform-ready content scripts.
Your role is to transform raw ideas into clear, structured, and engaging scripts while maintaining a natural human tone.

Your responsibilities:
- Understand the user’s topic, goal, audience, platform, and tone.
- Generate scripts with a strong hook (first 3–5 seconds) – attention grabbing.
- Provide a Core Message – value, story, or explanation.
- Include a Closing / CTA – action-oriented ending.
- Keep content concise, engaging, and easy to understand.
- Adapt writing style based on platform (Reels, Shorts, YouTube, Presentation, LinkedIn, etc.).
- Avoid robotic or generic language.
- Language must feel human and conversational.
- Avoid filler phrases and over-explanation.

Output must be a structured JSON object.
`;

  const userPrompt = `
Topic: ${request.topic}
Platform: ${request.platform}
Target Audience: ${request.audience}
Tone: ${request.tone}
Duration: ${request.duration}

Format the output strictly as JSON.
`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: [{ role: "user", parts: [{ text: userPrompt }] }],
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            hook: { 
              type: Type.STRING, 
              description: "The attention-grabbing first 3-5 seconds." 
            },
            coreMessage: { 
              type: Type.STRING, 
              description: "The main value or story content." 
            },
            cta: { 
              type: Type.STRING, 
              description: "The action-oriented closing." 
            },
            deliveryTips: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "3-4 professional suggestions for the creator."
            }
          },
          required: ["hook", "coreMessage", "cta", "deliveryTips"]
        },
        temperature: 0.8,
      }
    });

    const text = response.text;
    if (!text) throw new Error("Empty response from AI engine.");
    
    return JSON.parse(text) as ScriptOutput;
  } catch (err) {
    console.error("AI Generation Error:", err);
    throw err;
  }
};
