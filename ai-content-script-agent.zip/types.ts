
export enum Tone {
  MOTIVATIONAL = 'motivational',
  EDUCATIONAL = 'educational',
  CASUAL = 'casual',
  PROFESSIONAL = 'professional'
}

export interface ScriptRequest {
  topic: string;
  platform: string;
  audience: string;
  tone: Tone;
  duration: string;
}

export interface ScriptOutput {
  hook: string;
  coreMessage: string;
  cta: string;
  deliveryTips: string[];
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}

export interface SavedScript extends ScriptOutput {
  id: string;
  userId: string;
  title: string;
  timestamp: number;
  request: ScriptRequest;
}
