
import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import ScriptForm from './components/ScriptForm';
import ScriptDisplay from './components/ScriptDisplay';
import HowItWorks from './components/HowItWorks';
import Templates from './components/Templates';
import AuthModal from './components/AuthModal';
import SavedScripts from './components/SavedScripts';
import { generateScript } from './services/gemini';
import { ScriptRequest, ScriptOutput, User, SavedScript } from './types';

const App: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [script, setScript] = useState<ScriptOutput | null>(null);
  const [activeRequest, setActiveRequest] = useState<ScriptRequest | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [prefill, setPrefill] = useState<ScriptRequest | null>(null);
  
  // Auth & Storage State
  const [user, setUser] = useState<User | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [savedScripts, setSavedScripts] = useState<SavedScript[]>([]);
  const [isCurrentScriptSaved, setIsCurrentScriptSaved] = useState(false);

  // Load persistence from localStorage
  useEffect(() => {
    const storedUser = localStorage.getItem('agent_user');
    const storedScripts = localStorage.getItem('agent_scripts');
    
    if (storedUser) setUser(JSON.parse(storedUser));
    if (storedScripts) setSavedScripts(JSON.parse(storedScripts));
  }, []);

  // Sync state to localStorage
  useEffect(() => {
    if (user) {
      localStorage.setItem('agent_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('agent_user');
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem('agent_scripts', JSON.stringify(savedScripts));
  }, [savedScripts]);

  const handleGenerate = async (data: ScriptRequest) => {
    setLoading(true);
    setError(null);
    setIsCurrentScriptSaved(false);
    try {
      const result = await generateScript(data);
      setScript(result);
      setActiveRequest(data);
    } catch (err) {
      console.error(err);
      setError('AI service is currently unavailable. Please check your network or API key configuration.');
    } finally {
      setLoading(false);
    }
  };

  const handleTemplateSelect = (data: ScriptRequest) => {
    setPrefill(data);
    setScript(null);
  };

  const handleLogin = (newUser: User) => {
    setUser(newUser);
  };

  const handleSignOut = () => {
    setUser(null);
    setSavedScripts([]); // Clear view session-wise, but keep in localStorage for simplicity or clear all
    localStorage.removeItem('agent_user');
    localStorage.removeItem('agent_scripts');
  };

  const handleSaveScript = (title: string) => {
    if (!user || !script || !activeRequest) return;

    const newSavedScript: SavedScript = {
      ...script,
      id: Math.random().toString(36).substr(2, 9),
      userId: user.id,
      title: title,
      timestamp: Date.now(),
      request: activeRequest
    };

    setSavedScripts([newSavedScript, ...savedScripts]);
    setIsCurrentScriptSaved(true);
  };

  const handleDeleteSaved = (id: string) => {
    setSavedScripts(savedScripts.filter(s => s.id !== id));
  };

  const handlePreviewSaved = (saved: SavedScript) => {
    setScript(saved);
    setActiveRequest(saved.request);
    setIsCurrentScriptSaved(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] overflow-x-hidden selection:bg-indigo-100 selection:text-indigo-900">
      {/* Dynamic Background Elements */}
      <div className="fixed inset-0 overflow-hidden -z-10 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-200/30 rounded-full blur-[120px] animate-pulse"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-pink-200/20 rounded-full blur-[120px] animate-pulse" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-[20%] right-[10%] w-[30%] h-[30%] bg-violet-200/20 rounded-full blur-[100px] animate-pulse" style={{ animationDelay: '4s' }}></div>
      </div>

      <Header 
        user={user} 
        onSignInClick={() => setIsAuthModalOpen(true)} 
        onSignOut={handleSignOut}
      />
      
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start mb-20">
          {/* Left Column: Input Form */}
          <div className="lg:col-span-5">
            <div className="sticky top-28 space-y-6">
              <ScriptForm onSubmit={handleGenerate} isLoading={loading} prefill={prefill} />
              
              <div className="bg-white/60 backdrop-blur-md border border-slate-200 p-8 rounded-[32px] shadow-sm relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/5 rounded-full -mr-10 -mt-10 blur-xl group-hover:bg-indigo-500/10 transition-colors"></div>
                <h4 className="text-xs font-black text-indigo-700 uppercase tracking-[0.2em] mb-3 flex items-center gap-2">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                  Expert Insight
                </h4>
                <p className="text-sm text-slate-600 leading-relaxed font-medium">
                  "The first 3 seconds define your watch time. Use the 'Pattern Interrupt' technique for your hook to stop the scroll."
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Output Display */}
          <div className="lg:col-span-7 min-h-[600px]">
            {error && (
              <div className="bg-red-50 border border-red-200 p-8 rounded-[40px] mb-8 flex items-start gap-5 shadow-xl shadow-red-100/50">
                <div className="w-12 h-12 bg-red-100 rounded-2xl flex items-center justify-center text-red-600 shrink-0">
                  <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-red-900">Agent Disconnected</h3>
                  <p className="text-sm text-red-700 mt-1 font-medium">{error}</p>
                </div>
              </div>
            )}

            {!script && !loading && (
              <div className="h-full flex flex-col items-center justify-center py-40 px-12 border-2 border-dashed border-slate-200 rounded-[60px] bg-white/50 backdrop-blur-sm text-slate-400 text-center group hover:border-indigo-300 transition-colors">
                <div className="w-24 h-24 bg-slate-100 rounded-[32px] flex items-center justify-center mb-8 group-hover:scale-110 group-hover:bg-indigo-50 transition-all duration-500">
                  <svg className="w-12 h-12 text-slate-300 group-hover:text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
                  </svg>
                </div>
                <h3 className="text-2xl font-black text-slate-800 tracking-tight">Intelligence on Standby</h3>
                <p className="text-base max-w-sm mt-4 leading-relaxed font-medium">
                  Select a template or type your topic to begin. Our Agent is ready to craft your next viral script.
                </p>
              </div>
            )}

            {loading && (
              <div className="space-y-6">
                <div className="bg-white p-12 rounded-[60px] shadow-2xl shadow-indigo-100/20 border border-slate-100 overflow-hidden relative">
                  <div className="absolute top-0 left-0 w-full h-2 bg-slate-100">
                    <div className="h-full bg-indigo-600 animate-[loading_2s_infinite]"></div>
                  </div>
                  <style>{`
                    @keyframes loading {
                      0% { width: 0%; left: 0%; }
                      50% { width: 100%; left: 0%; }
                      100% { width: 0%; left: 100%; }
                    }
                  `}</style>
                  <div className="flex items-center gap-6 mb-12">
                    <div className="w-16 h-16 bg-indigo-50 rounded-2xl flex items-center justify-center shadow-inner">
                       <svg className="w-8 h-8 text-indigo-600 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
                    </div>
                    <div>
                      <h4 className="text-lg font-black text-slate-800 uppercase tracking-widest leading-none">Creative Synthesis</h4>
                      <p className="text-sm text-slate-400 mt-2 font-medium italic">Gemini 3 Pro is thinking...</p>
                    </div>
                  </div>
                  <div className="space-y-6">
                    <div className="h-5 bg-slate-50 rounded-full w-3/4 animate-pulse"></div>
                    <div className="h-5 bg-slate-50 rounded-full w-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                    <div className="h-5 bg-slate-50 rounded-full w-5/6 animate-pulse" style={{ animationDelay: '0.4s' }}></div>
                    <div className="h-5 bg-slate-50 rounded-full w-full animate-pulse" style={{ animationDelay: '0.6s' }}></div>
                    <div className="h-24 bg-slate-50/50 rounded-[24px] mt-10 animate-pulse" style={{ animationDelay: '0.8s' }}></div>
                  </div>
                </div>
              </div>
            )}

            {script && activeRequest && !loading && (
              <ScriptDisplay 
                script={script} 
                request={activeRequest}
                user={user}
                onSave={handleSaveScript}
                onSignInRequired={() => setIsAuthModalOpen(true)}
                isSaved={isCurrentScriptSaved}
              />
            )}
          </div>
        </div>

        {/* Library Section */}
        {user && (
          <SavedScripts 
            scripts={savedScripts} 
            onDelete={handleDeleteSaved} 
            onPreview={handlePreviewSaved} 
          />
        )}
        
        {/* Landing Sections */}
        <HowItWorks />
        <Templates onSelect={handleTemplateSelect} />

      </main>
      
      <footer className="bg-slate-900 text-slate-400 py-20 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-indigo-500/20 to-transparent"></div>
        <div className="max-w-6xl mx-auto px-4 text-center relative z-10">
          <div className="inline-flex items-center justify-center w-12 h-12 bg-white/5 rounded-2xl mb-8 border border-white/10">
            <svg className="w-6 h-6 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
            </svg>
          </div>
          <p className="text-sm uppercase tracking-[0.4em] font-black text-white/90 mb-4">Script Agent Studio</p>
          <p className="text-sm max-w-xl mx-auto leading-relaxed text-slate-500 font-medium">
            Join the elite circle of creators using Gemini 3 Pro reasoning. Turn static ideas into high-velocity digital content.
          </p>
          <div className="mt-12 pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-6">
             <p className="text-xs font-bold text-slate-600 tracking-wider">© 2024 AI SCRIPT AGENT. ALL RIGHTS RESERVED.</p>
             <div className="flex gap-8">
                <a href="#" className="text-xs font-bold text-slate-600 hover:text-indigo-400 transition-colors">PRIVACY</a>
                <a href="#" className="text-xs font-bold text-slate-600 hover:text-indigo-400 transition-colors">TERMS</a>
                <a href="#" className="text-xs font-bold text-slate-600 hover:text-indigo-400 transition-colors">API STATUS</a>
             </div>
          </div>
        </div>
      </footer>

      <AuthModal 
        isOpen={isAuthModalOpen} 
        onClose={() => setIsAuthModalOpen(false)} 
        onLogin={handleLogin} 
      />
    </div>
  );
};

export default App;
